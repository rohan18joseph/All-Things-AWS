import requests
import json

def lambda_handler(event, context):
    print(event)
    url = ""https://hooks.slack.com/workflows/whatevertherestoftheurlis"
    cont=event['Records'][0]['Sns']['Message']
    msg = {"Content":cont}
    headers = {'content-type': "application/json",'cache-control': "no-cache"}
    response = requests.request("POST", url, data=json.dumps(msg),headers=headers)
    print(response.text)